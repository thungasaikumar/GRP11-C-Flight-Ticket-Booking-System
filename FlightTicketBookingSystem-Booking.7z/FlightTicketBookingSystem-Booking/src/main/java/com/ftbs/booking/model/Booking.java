package com.ftbs.booking.model;
//
//
//import java.time.LocalDate;
//import java.util.List;
//
//import javax.persistence.ElementCollection;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//import com.fasterxml.jackson.annotation.JsonFormat;
//
//@Entity
//@Table(name = "booking")
//public class Booking {
//
//	@Id
//	private long bookingId;
//
////	@OneToOne
////	@JoinColumn(name = "userId")
////	private User userId;
//
//	@JsonFormat(pattern = "yyyy-MM-dd")
//	private LocalDate bookingDate;
//
//	//@Column
//	@ElementCollection
//	private List<Long> passengerList; // private List<Passenger> passengerList;
//
//	private double ticketCost;
//
//	//@OneToMany
//	//@JoinColumn(name = "flightNumber")
//	//private Flight flightNumber; // private Flight flight;
//
//	private int noOfPassengers;
//
////	public Booking(long l, long m, LocalDate localDate, List<Long> lst, double d, long n, int i) {
////	}
//
//	public Booking(long bookingId, LocalDate bookingDate, List<long> passengerList, double ticketCost, int noOfPassengers) {
//		super();
//		this.bookingId = bookingId;
//		this.bookingDate = bookingDate;
//		this.passengerList = passengerList;
//		this.ticketCost = ticketCost;
//		//this.flightNumber = flightNumber;
//		this.noOfPassengers = noOfPassengers;
//	}
//
//	public long getBookingId() {
//		return bookingId;
//	}
//
//	public void setBookingId(long bookingId) {
//		this.bookingId = bookingId;
//	}
//
//	public LocalDate getBookingDate() {
//		return bookingDate;
//	}
//
//	public void setBookingDate(LocalDate bookingDate) {
//		this.bookingDate = bookingDate;
//	}
//
//	public double getTicketCost() {
//		return ticketCost;
//	}
//
//	public void setTicketCost(double ticketCost) {
//		this.ticketCost = ticketCost;
//	}
//
//	public int getNoOfPassengers() {
//		return noOfPassengers;
//	}
//
//	public void setNoOfPassengers(int noOfPassengers) {
//		this.noOfPassengers = noOfPassengers;
//	}
//
////	public User getUserId() {
////		return userId;
////	}
////
////	public void setUserId(User userId) {
////		this.userId = userId;
////	}
//
//	public List<Long> getPassengerList() {
//		return passengerList;
//	}
//
//	public void setPassengerList(List<long> passengerList) {
//		this.passengerList = passengerList;
//	}
//
////	public Flight getFlightNumber() {
////		return flightNumber;
////	}
////
////	public void setFlightNumber(Flight flightNumber) {
////		this.flightNumber = flightNumber;
////	}
//
//	@Override
//	public String toString() {
//		return "Booking [bookingId=" + bookingId + ", bookingDate=" + bookingDate
//				+ ", passengerList=" + passengerList + ", ticketCost=" + ticketCost
//				+ ", noOfPassengers=" + noOfPassengers + "]";
//	}
//
//}



import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
@Table(name="booking")
public class Booking implements Serializable{
    
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private long bookingId;
    private long userId;                  //private User userId;
    @JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate bookingDate;
	private String passengerName; 
	
//    @ElementCollection
//	private List<Long> passengerList;
	private double ticketCost;
	private long flightNumber;            //private Flight flight;
	private int noOfPassengers;

	public Booking() {	}
	
	public Booking(long bookingId, long userId, LocalDate bookingDate, String passengerName, double ticketCost,
			long flightNumber, int noOfPassengers) {
		super();
		this.bookingId = bookingId;
		this.userId = userId;
		this.bookingDate = bookingDate;
		this.passengerName = passengerName;
		this.ticketCost = ticketCost;
		this.flightNumber = flightNumber;
		this.noOfPassengers = noOfPassengers;
	}

	public long getBookingId() {
		return bookingId;
	}

	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}

    public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public LocalDate getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}

	public double getTicketCost() {
		return ticketCost;
	}


	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}

	
	public long getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(long flightNumber) {
		this.flightNumber = flightNumber;
	}

	public int getNoOfPassengers() {
		return noOfPassengers;
	}

	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

//	public List<Long> getPassengerList() {
//		return passengerList;
//	}
//
//	public void setPassengerList(List<Long> passengerList) {
//		this.passengerList = passengerList;
//	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", userId=" + userId + ", bookingDate=" + bookingDate
				+ ", passengerList=" + passengerName + ", ticketCost=" + ticketCost + ", flightNumber=" + flightNumber
				+ ", noOfPassengers=" + noOfPassengers + "]";
	}

}
