package com.ftbs.schedule.service;

public interface IAvailabilityService {

	String checkScheduledFlightById(int flightNumber);

	boolean checkSeatAvailability(int flightNumber, int availableSeats);

	String checkSource(int flightNumber, String sourceAirport);

	String checkDestination(int flightNumber, String destinationAirport);

	String checkSourceAndDestination(String sourceAirport, String destinationAirport);

}