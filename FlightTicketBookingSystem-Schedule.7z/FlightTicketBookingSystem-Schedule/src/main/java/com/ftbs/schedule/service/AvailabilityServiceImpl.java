package com.ftbs.schedule.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ftbs.schedule.excepions.InvalidInputException;
import com.ftbs.schedule.repository.IAvailabilityScheduleRepo;
import com.ftbs.schedule.repository.IAvailabilityScheduledFlightRepo;

@Service
public class AvailabilityServiceImpl implements IAvailabilityService {

	@Autowired
	IAvailabilityScheduledFlightRepo flightRepository;

	@Autowired
	IAvailabilityScheduleRepo scheduleRepo;

	@Override
	public String checkScheduledFlightById(int flightNumber) {

		if (!flightRepository.existsByFlightNumber(flightNumber)) {

			throw new InvalidInputException("No availability");
		}
		return "The flight is available";
	}

	@Override
	public boolean checkSeatAvailability(int flightNumber, int availableSeats) {

		if (!flightRepository.existsByFlightNumber(flightNumber)) {
			throw new InvalidInputException("Please Check Flight Number");
		} else if (flightRepository.existsAvailableSeats(availableSeats) != flightRepository.exists(availableSeats)
				|| availableSeats <= 0) {
			throw new InvalidInputException("No availability");
		}
		return true;
	}

	@Override
	public String checkSource(int flightNumber, String sourceAirport) {
		if (flightRepository.existsByFlightNumber(flightNumber)) {
			if (!scheduleRepo.findAll().contains(scheduleRepo.existsSourceAirport(sourceAirport))) {
				throw new InvalidInputException("Source Airport is not valid");
			}
		}
		return "Source Airport is valid";
	}

	@Override
	public String checkDestination(int flightNumber, String destinationAirport) {
		if (flightRepository.existsByFlightNumber(flightNumber)) {
			if (!scheduleRepo.findAll().contains(scheduleRepo.existsDestinationAirport(destinationAirport))) {
				throw new InvalidInputException("Destination Airport is not valid");
			}
		}
		return "Destination Airport is valid";
	}

	@Override
	public String checkSourceAndDestination(String sourceAirport, String destinationAirport) {

		if (!scheduleRepo.findAll().contains(scheduleRepo.existsSourceAirport(sourceAirport))) {
			throw new InvalidInputException("Flight is not available");
		} else if (!flightRepository.findAll().contains(scheduleRepo.existsDestinationAirport(destinationAirport))) {
			throw new InvalidInputException("Flight is not available");
		}

		return "Flight is available";
	}

	/*
	 * @Override public boolean validateFlightId(long flightNumber) {
	 * 
	 * int count=0; while(flightNumber>0) { count++; flightNumber=flightNumber/10; }
	 * 
	 * if(count<3 || count>3) { throw new
	 * InvalidInputException("ID should be of 12 digits"); } return
	 */ // true;
	// }
}