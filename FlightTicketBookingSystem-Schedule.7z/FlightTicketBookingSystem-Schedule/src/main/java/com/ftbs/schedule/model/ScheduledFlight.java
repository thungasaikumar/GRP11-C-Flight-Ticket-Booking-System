package com.ftbs.schedule.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ScheduledFlight")
public class ScheduledFlight {

	@Id
	@Column(name = "scheduledFlightId")
	private int scheduledFlightId;

	@Column(name = "availableSeats")
	private int availableSeats;

	@Column(name = "flightNumber")
	private int flightNumber;

//	@OneToOne(cascade = { CascadeType.ALL })
//	@JoinColumn(name = "schedule", referencedColumnName = "scheduleId")
//	private Schedule schedule;
	
	private String scheduleId;

	public ScheduledFlight() {
		super();

	}

	public ScheduledFlight(int scheduleFlightId, int availableSeats, int flightNumber, String scheduleId) {
		super();
		this.scheduledFlightId = scheduleFlightId;
		this.availableSeats = availableSeats;
		this.flightNumber = flightNumber;
		this.scheduleId = scheduleId;

	}

	public int getScheduledFlightId() {
		return scheduledFlightId;
	}

	public void setScheduledFlightId(int scheduledFlightId) {
		this.scheduledFlightId = scheduledFlightId;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public int getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}

//	public Schedule getSchedule() {
//		return schedule;
//	}
//
//	public void setSchedule(Schedule schedule) {
//		this.schedule = schedule;
//	}

	public String getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(String scheduleId) {
		this.scheduleId = scheduleId;
	}

	@Override
	public String toString() {
		return "ScheduledFlight [scheduledFlightId=" + scheduledFlightId + ", availableSeats=" + availableSeats
				+ ", flightNumber=" + flightNumber + "ScheduleId" + scheduleId+ "]";
	}

}
