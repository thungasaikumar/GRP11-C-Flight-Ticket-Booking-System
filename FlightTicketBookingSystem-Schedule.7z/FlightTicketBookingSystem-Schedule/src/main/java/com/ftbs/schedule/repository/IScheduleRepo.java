package com.ftbs.schedule.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ftbs.schedule.model.ScheduledFlight;

@Repository
public interface IScheduleRepo extends JpaRepository<ScheduledFlight, Integer> {

}
