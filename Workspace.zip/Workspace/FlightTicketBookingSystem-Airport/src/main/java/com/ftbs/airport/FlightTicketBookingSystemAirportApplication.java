package com.ftbs.airport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightTicketBookingSystemAirportApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightTicketBookingSystemAirportApplication.class, args);
		System.out.println("Airport-application started");
	}

}
