package com.ftbs.airport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightTicketBookingSystemAirportApplicationTests {

	@Test
	void contextLoads() {
	}

}
