package com.ftbs.booking.service;

import com.ftbs.booking.model.Booking;
import com.ftbs.booking.model.BookingList;
import com.ftbs.booking.model.Passenger;
import com.ftbs.booking.model.PassengerList;

public interface IBookingService {

	Booking addBooking(Booking booking);

	Booking viewBookingByBookingId(long bookingId);

	BookingList viewAllBookings();

	Booking modifyBooking(Booking booking);

	boolean deleteBooking(long bookingId);

	boolean validateBookingId(long bookingId);

	boolean validateUserId(long id);

	boolean validateNoOfPAssengers(int noOfPassengers);

	void validateBooking(Booking booking);

	void validatePassenger(Passenger passenger);

	PassengerList viewAllPassengers();

}
