package com.ftbs.booking.exceptions;


public class BookingIdNotFoundException extends RuntimeException{

	public BookingIdNotFoundException(String message) {
		super(message);
	}
}
