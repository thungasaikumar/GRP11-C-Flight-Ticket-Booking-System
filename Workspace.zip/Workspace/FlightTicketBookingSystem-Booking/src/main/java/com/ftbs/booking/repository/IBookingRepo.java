package com.ftbs.booking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ftbs.booking.model.Booking;

@Repository
public interface IBookingRepo extends JpaRepository<Booking, Long>{

	//public Booking viewBookingByBookingId(long bookingId);
	
}
