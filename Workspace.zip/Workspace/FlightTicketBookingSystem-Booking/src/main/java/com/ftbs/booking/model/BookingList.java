package com.ftbs.booking.model;

import java.util.List;

public class BookingList {

	private List<Booking> bookingList;

	
	public BookingList() {
		super();
	}

	public BookingList(List<Booking> bookingList) {
		super();
		this.bookingList = bookingList;
	}

	public List<Booking> getBookingList() {
		return bookingList;
	}

	public void setBookingList(List<Booking> bookingList) {
		this.bookingList = bookingList;
	}
	
	
	
}
