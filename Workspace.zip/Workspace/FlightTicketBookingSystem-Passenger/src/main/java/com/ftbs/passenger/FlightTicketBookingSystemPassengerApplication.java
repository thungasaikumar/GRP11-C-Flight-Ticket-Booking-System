package com.ftbs.passenger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightTicketBookingSystemPassengerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightTicketBookingSystemPassengerApplication.class, args);
		System.out.println("Passenger-application started");
	}

}
