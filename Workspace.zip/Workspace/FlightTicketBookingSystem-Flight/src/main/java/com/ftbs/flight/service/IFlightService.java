package com.ftbs.flight.service;

import com.ftbs.flight.model.Flight;
import com.ftbs.flight.model.FlightList;


public interface IFlightService {
	

	public Flight addFlight(Flight flight);
	
	public Flight modifyFlight(Flight flight);
	
	public void deleteFlight(long flightNumber);
		
	 public Flight getFlightById(long flightNumber);
	 
	public FlightList getAll();
	
	

}
