package com.ftbs.flight.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ftbs.flight.model.Flight;
import com.ftbs.flight.model.FlightList;
import com.ftbs.flight.service.FlightServiceImpl;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/flights")
public class FlightController {
	

	@Autowired
	FlightServiceImpl flightservice;

	

	@PostMapping("/add")
	public Flight addFlight( @RequestBody Flight flight) {
		
		return flightservice.addFlight(flight);
	}

	

	@DeleteMapping("/deleteById/{flightNumber}")
	public ResponseEntity<Flight> deleteFlight(@Valid @PathVariable long flightNumber) {
		flightservice.deleteFlight(flightNumber);
		return new ResponseEntity<Flight>(HttpStatus.OK);

	}

	
	
	@GetMapping("/all")
	public ResponseEntity<FlightList> getAllFlights() {
		FlightList allFlights = flightservice.getAll();
		return new ResponseEntity<FlightList>(allFlights, HttpStatus.OK);
	}

	
	@PutMapping("/modify")
	public ResponseEntity<Flight> modifyFlight(@Valid @RequestBody Flight flight) {
		Flight newFlight = flightservice.modifyFlight(flight);
		return new ResponseEntity<Flight>(flight, HttpStatus.OK);
	}

	@GetMapping("/id/{flightNumber}")
	public ResponseEntity<Flight> getFlightById(@PathVariable int flightNumber) {

		Flight flight = flightservice.getFlightById(flightNumber);

		return new ResponseEntity<Flight>(flight, HttpStatus.OK);
	}

	@ExceptionHandler(Exception.class)
	public String inValid(Exception e) {
		return e.getMessage();
	}

}
