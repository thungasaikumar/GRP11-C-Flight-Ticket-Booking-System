package com.ftbs.schedule;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ftbs.schedule.excepions.InvalidInputException;
import com.ftbs.schedule.service.IAvailabilityService;

@SpringBootTest
class FmsScheduleMsAvailabilityTests {

	@Autowired
	IAvailabilityService availabilityService;
	
//	 @Test public void testFlightNumberwithLessDigits() throws
//	 InvalidInputException {
//	 Exception exception = assertThrows(InvalidInputException.class, () -> {
//	 availabilityService.validateFlightId(4567890L); }); String expectedMessage =
//	 "ID should be of 12 digits"; String actualMessage = exception.getMessage();
//	 assertTrue(actualMessage.contains(expectedMessage)); }
//	 

	/*
	 * @Test public void testFlightNumberwithMoreDigits() throws
	 * InvalidInputException { Exception exception =
	 * assertThrows(InvalidInputException.class, () -> {
	 * availabilityService.validateFlightId(1234345678907856L); });
	 * 
	 * String expectedMessage = "ID should be of 12 digits"; String actualMessage =
	 * exception.getMessage(); assertTrue(actualMessage.contains(expectedMessage));
	 * }
	 */

	@Test
	public void testFlightNumber() {
		assertEquals("The flight is available", availabilityService.checkScheduledFlightById(44));
	}

	@Test
	public void testSourceAirport() throws InvalidInputException {
		Exception exception = assertThrows(InvalidInputException.class, () -> {
			availabilityService.checkSource(44, "Vizag");
		});

		String expectedMessage = "Source Airport is not valid";
		String actualMessage = exception.getMessage();
		assertTrue(actualMessage.contains(expectedMessage));
	}

	@Test
	public void testDestinationAirport() throws InvalidInputException {
		Exception exception = assertThrows(InvalidInputException.class, () -> {
			availabilityService.checkDestination(44, "Mumbai");
		});

		String expectedMessage = "Destination Airport is not valid";
		String actualMessage = exception.getMessage();
		assertTrue(actualMessage.contains(expectedMessage));
	}


	

	/*
	 * @Test public void testAvailableSeats() {
	 * assertTrue(availabilityService.checkSeatAvailability(446233628412L, 21)); }
	 */
}

