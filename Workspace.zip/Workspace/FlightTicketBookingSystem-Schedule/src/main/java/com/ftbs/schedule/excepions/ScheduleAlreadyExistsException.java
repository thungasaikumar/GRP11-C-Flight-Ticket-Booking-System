package com.ftbs.schedule.excepions;

public class ScheduleAlreadyExistsException extends RuntimeException {

	public ScheduleAlreadyExistsException(String message) {
		
		super(message);
		
	}
	
}
