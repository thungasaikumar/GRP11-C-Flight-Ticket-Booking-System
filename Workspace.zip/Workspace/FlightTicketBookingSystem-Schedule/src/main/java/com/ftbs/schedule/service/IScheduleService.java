package com.ftbs.schedule.service;

import com.ftbs.schedule.model.ScheduledFlight;
import com.ftbs.schedule.model.ScheduledFlightList;

public interface IScheduleService {

	public ScheduledFlight addScheduleFlight(ScheduledFlight scheduledFlight);

	public ScheduledFlight viewScheduledFlight(int scheduleId);

	public ScheduledFlightList viewScheduledFlight();

	public ScheduledFlight modifyScheduledFlight(int scheduledFlightId, int availableSeats, int flightNumber);

	public void deleteScheduledFlight(int scheduledFlightId);

}
