package com.ftbs.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ftbs.user.model.Booking;
import com.ftbs.user.model.BookingList;
import com.ftbs.user.model.FlightList;
import com.ftbs.user.model.Passenger;
import com.ftbs.user.model.PassengerList;
import com.ftbs.user.model.ScheduledFlightList;

@Service
public class CustomerService implements ICustomerService {

	@Autowired
	RestTemplate restTemplate;

	@Override
	public FlightList viewAllFlights() {
		return restTemplate.getForObject("http://localhost:9002/flights/all", FlightList.class);
	}

	public String checkScheduledFlightById(int flightNumber) {
		return restTemplate.getForObject("http://localhost:9005/availabilityflight/" + flightNumber, String.class);
	}

	public String checkSeatAvailability(int flightNumber, int availableSeats) {
		return restTemplate.getForObject(
				"http://localhost:9005/availabilityflight/" + flightNumber + "/" + availableSeats, String.class);
	}

	public String checkSource(int flightNumber, String sourceAirport) {
		return restTemplate.getForObject(
				"http://localhost:9005/availabilityflight/" + flightNumber + "/source/" + sourceAirport, String.class);
	}

	public String checkDestination(int flightNumber, String destinationAirport) {
		return restTemplate.getForObject(
				"http://localhost:9005/availabilityflight/" + flightNumber + "/destination/" + destinationAirport,
				String.class);
	}

	public String checkSourceAndDestination(String sourceAirport, String destinationAirport) {
		return restTemplate.getForObject("http://localhost:9005/availabilityflight/source/" + sourceAirport
				+ "/destination/" + destinationAirport, String.class);
	}

	@Override
	public Booking makeBooking(Booking booking) {
		return restTemplate.postForObject("http://localhost:9004/booking/add", booking, Booking.class);

	}

	@Override
	public BookingList viewBookingList() {
		return restTemplate.getForObject("http://localhost:9004/booking/all", BookingList.class);
	}

	@Override
	public void cancelBooking(long bookingId) {
		restTemplate.delete("http://localhost:9004/booking/delete/" + bookingId);
	}

	@Override
	public Booking modifyBooking(Booking booking) {
		return restTemplate.postForObject("http://localhost:9004/booking/modify", booking, Booking.class);
	}

	@Override
	public Booking viewBookingByBookingId(long bookingId) {
		return restTemplate.getForObject("http://localhost:9004/booking/id/" + bookingId, Booking.class);
	}

	@Override
	public Passenger addPassenger(Passenger passenger) {
		return restTemplate.postForObject("http://localhost:9001/passenger/add", passenger, Passenger.class);
	}

	@Override
	public void deletePassenger(long passengerNum) {
		restTemplate.delete("http://localhost:9001/passenger/delete/num/" + passengerNum);
	}

	@Override
	public Passenger getPassenger(long passengerNum) {
		return restTemplate.getForObject("http://localhost:9001/passenger/num/" + passengerNum, Passenger.class);
	}

	@Override
	public PassengerList getAllPasssengers() {
		return restTemplate.getForObject("http://localhost:9001/passenger/all", PassengerList.class);
	}

	@Override
	public Passenger updatePassenger(Passenger passenger) {
		return restTemplate.postForObject("http://localhost:9001/passenger/update", passenger, Passenger.class);
	}

	@Override
	public long getCountOfPassenger() {
		return restTemplate.getForObject("http://localhost:9001/passenger/getcount", long.class);
	}

	public ScheduledFlightList viewAllScheduledFlight() {
		return restTemplate.getForObject("http://localhost:9005/scheduleflight/viewall", ScheduledFlightList.class);
	}

}
