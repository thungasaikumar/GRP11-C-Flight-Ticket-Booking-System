package com.ftbs.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import com.ftbs.user.model.User;
import com.ftbs.user.model.UserCredentials;
import com.ftbs.user.service.ILoginService;

@RestController
@RequestMapping("/users")
@CrossOrigin("http://localhost:4200")
public class LoginController {

	@Autowired
	ILoginService service;
	
	
	@PostMapping("/public/authenticate")
	public User authenticateUser(@RequestBody UserCredentials credentials) {
		User user=service.getUser(credentials.getUsername());
		
		if(user==null) {
			throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
		}
		else if(!(credentials.getPassword()).equals(user.getUserPassword())) {
			throw new ResponseStatusException(HttpStatus.UNAUTHORIZED) ;
		}
		else 
			return user;
		
	}
	

	
}
