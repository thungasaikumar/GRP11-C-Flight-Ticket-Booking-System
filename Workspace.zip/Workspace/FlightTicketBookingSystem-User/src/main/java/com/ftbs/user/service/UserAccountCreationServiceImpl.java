package com.ftbs.user.service;

import java.util.Arrays;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.ftbs.user.exceptions.InvalidInputException;
import com.ftbs.user.model.User;
import com.ftbs.user.repository.IUserJpaRepo;

@Service
public class UserAccountCreationServiceImpl implements IUserAccountCreationService {
	
	@Autowired
	IUserJpaRepo repo;
	
	@PostConstruct
	public void addSomeUsers() {
		User user1=new User("admin",125364125321L,"shilpa23","shilpa@uel23",9854235621L,"shilpa@gmail.com");
		User user2=new User("user",125364125325L,"netha88","netha@uel88",9854235625L,"netha@gmail.com");
		repo.saveAll(Arrays.asList(user1,user2));
	}
	
	
	@Override
	public User addUser(User user) {
		if(repo.existsByUserName(user.getUserName()) || repo.existsByUserId(user.getUserId())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
		}
		return repo.save(user);
	}
	

	@Override
	public User getUserByUserName(String userName) {
		return repo.getUserByUserName(userName);
	}
	
	public boolean validateUserPhoneNo(long phoneNo) {
		String s=Long.toString(phoneNo);
		if(!(s.length()==10 && s.charAt(0)!=0)) {
			throw new InvalidInputException("Phone number should be of 10 digits");
		}
		return true;	
	}

	
	public boolean validateUserEmail(String email)  {
	      String regex = "[A-Za-z0-9]+@[A-Za-z]+\\.[A-Za-z]{2,4}";
	      if(email.matches(regex))
	    	  return true;
	      else
	    	  throw new InvalidInputException("Email Id NOT valid");
	   }

		
	public boolean validateUserId(long id) {
		int count=0;
		while(id>0) {
			long denominator=id % 10;
			count++;
			id=id/10;
		}
		if(count!=12)
			throw new InvalidInputException("ID should be of 12 digits");	

		return true;
			
	}
	
	
	public boolean validateUserPassword(String password) {
		String regex="[?=.*[a-zA-Z0-9@#&]]{8,}";
		if(password.matches(regex)) {
			return true;
		}
		else 
			throw new InvalidInputException("Password can contain:- [uppercase, lowercase, numeric,{'@','&','#'} ONLY and should be of at least 8 characters]");
	}
	
	
	public boolean validateUserName(String userName) {
		
		String regex="[?=.*[a-zA-Z0-9]]{8,}";
		if(!userName.matches(regex)) {
			throw new InvalidInputException("Username should contain atleast 8 characters and can be alphanumeric ONLY");
			
		}
		return true;
	}
	
	
	public boolean validateUserType(String userType) {
		if((userType.toLowerCase()).equals("admin") || (userType.toLowerCase()).equals("user")){
			return true;
		}
		else 
			throw new InvalidInputException("UserType should be either USER or ADMIN");
	}

}
