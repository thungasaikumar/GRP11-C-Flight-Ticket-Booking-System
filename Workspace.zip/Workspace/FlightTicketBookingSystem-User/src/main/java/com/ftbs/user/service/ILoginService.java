package com.ftbs.user.service;

import com.ftbs.user.model.User;

public interface ILoginService {
		
	public User getUser(String userName);

}
