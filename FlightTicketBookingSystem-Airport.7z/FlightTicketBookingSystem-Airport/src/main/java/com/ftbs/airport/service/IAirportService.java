package com.ftbs.airport.service;

import com.ftbs.airport.model.Airport;
import com.ftbs.airport.model.AirportList;

public interface IAirportService {
	
	AirportList getAllAirports();
	Airport getAirportByCode(String airportCode);
	Airport addAirport(Airport airport);
	void deleteAirport(String airportCode);
	public Airport getAirportByName(String airportName);
	
}
