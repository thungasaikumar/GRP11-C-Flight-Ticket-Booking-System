package com.ftbs.user.service;

import com.ftbs.user.model.Airport;
import com.ftbs.user.model.AirportList;
import com.ftbs.user.model.Flight;
import com.ftbs.user.model.FlightList;
import com.ftbs.user.model.ScheduledFlight;
import com.ftbs.user.model.ScheduledFlightList;

public interface IAdminService {
	
	FlightList viewAllFlights();
	Flight addFlight(Flight flight);
	Flight viewFlight(long flightId);
	void cancelFlight(long flightId);
	Flight modifyFlight(Flight flight);
	
	ScheduledFlight addScheduledFlight (ScheduledFlight  flight);
	ScheduledFlight  viewScheduledFlight (long scheduledFlightId);
	void cancelScheduledFlight (long scheduledFlightId);
	ScheduledFlight modifyScheduledFlight(ScheduledFlight  flight);
	public ScheduledFlightList viewAllScheduledFlight();

	
	AirportList getAllAirports();
	Airport getAirportByCode(String airportCode);
	Airport addAirport(Airport airport);
	void deleteAirport(String airportCode);
}
