package com.ftbs.user.exceptions;

public class InvalidUserNameAndPasswordException extends RuntimeException{
	
	public InvalidUserNameAndPasswordException(String message) {
		super(message);
	}

}