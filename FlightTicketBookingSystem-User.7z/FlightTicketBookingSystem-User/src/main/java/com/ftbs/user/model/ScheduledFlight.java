package com.ftbs.user.model;

public class ScheduledFlight {

	private int scheduledFlightId;
	private int availableSeats;
	private int flightNumber;

	public ScheduledFlight() {
		super();

	}

	public ScheduledFlight(int scheduleFlightId, int availableSeats, int flightNumber, Schedule schedule) {
		super();
		this.scheduledFlightId = scheduleFlightId;
		this.availableSeats = availableSeats;
		this.flightNumber = flightNumber;

	}

	public int getScheduledFlightId() {
		return scheduledFlightId;
	}

	public void setScheduledFlightId(int scheduledFlightId) {
		this.scheduledFlightId = scheduledFlightId;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public int getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}

	@Override
	public String toString() {
		return "ScheduledFlight [scheduledFlightId=" + scheduledFlightId + ", availableSeats=" + availableSeats
				+ ", flightNumber=" + flightNumber + "]";
	}

}
