package com.ftbs.flight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightTicketBookingSystemFlightApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightTicketBookingSystemFlightApplication.class, args);
		System.out.println("Flight-application started");
	}

}
