package com.ftbs.flight.exception;

public class FlightAlreadyExistException extends RuntimeException {

	public FlightAlreadyExistException(String message) {

			super(message);

		}

	}

