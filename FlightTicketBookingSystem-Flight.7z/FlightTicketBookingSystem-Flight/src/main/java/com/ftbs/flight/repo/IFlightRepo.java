package com.ftbs.flight.repo;
  
import org.springframework.data.jpa.repository.JpaRepository;
  
import com.ftbs.flight.model.Flight;
  
public interface IFlightRepo extends JpaRepository<Flight, Long>{

 }