package com.ftbs.passenger.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ftbs.passenger.model.Passenger;

@Repository
public interface IPassengerRepo extends JpaRepository<Passenger, Long>{


}
